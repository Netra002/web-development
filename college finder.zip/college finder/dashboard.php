<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "college finder");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$collegeData = null;
$searchQuery = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchQuery = trim($_POST["college_name"]);

    if (!empty($searchQuery)) {
        $stmt = $conn->prepare("SELECT * FROM colleges WHERE name LIKE ?");
        $likeSearch = "%" . $searchQuery . "%";
        $stmt->bind_param("s", $likeSearch);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $_SESSION["college_results"] = $result->fetch_all(MYSQLI_ASSOC);
        } else {
            $_SESSION["college_results"] = [];
        }

        $_SESSION["searchQuery"] = $searchQuery;
    } else {
        $_SESSION["college_results"] = null;
        $_SESSION["searchQuery"] = "";
    }

    header("Location: dashboard.php");
    exit();
}

if (isset($_SESSION["searchQuery"])) {
    $searchQuery = $_SESSION["searchQuery"];
    if (!empty($searchQuery)) {
        $collegeData = $_SESSION["college_results"];
    }
    unset($_SESSION["college_results"]);
    unset($_SESSION["searchQuery"]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

<!-- Top Bar -->
<div class="top-bar">
  <div class="user-info">
    Logged in as: <strong><?php echo htmlspecialchars($_SESSION["username"]); ?></strong>
  </div>
  <div class="top-bar-links">
    <a class="contact-link" href="contact.php"><i class="fas fa-envelope"></i><span> Contact Us</span></a>
    <a class="logout-link" href="php/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</div>

<!-- ✅ Review Success Message -->
<?php if (isset($_GET['review_success'])): ?>
  <div class="success-banner" id="successBanner">
    <span class="close-btn" onclick="dismissBanner()">×</span>
    <i class="fas fa-check-circle"></i> Review submitted successfully!
  </div>

  <script>
    function dismissBanner() {
      const banner = document.getElementById("successBanner");
      if (banner) banner.style.display = "none";
    }

    // Auto dismiss after 4 seconds
    setTimeout(() => {
      dismissBanner();
      if (history.replaceState) {
        const cleanUrl = window.location.origin + window.location.pathname;
        history.replaceState(null, '', cleanUrl);
      }
    }, 4000);
  </script>
<?php endif; ?>

<!-- Main Content -->
<div class="main-content">
  <h1>Welcome to Your Dashboard 🎉</h1>

  <div class="icon-title">
    <i class="fas fa-search"></i>
    <h2>Search for a College</h2>
  </div>

  <form method="POST">
    <input type="text" name="college_name" id="collegeInput" placeholder="Enter college name..." value="<?php echo htmlspecialchars($searchQuery); ?>" required>
    <button type="submit"><i class="fas fa-magnifying-glass"></i> Search</button>
  </form>

  <div id="resultsContainer">
    <?php if ($collegeData !== null): ?>
      <?php if (count($collegeData) > 0): ?>
        <?php foreach ($collegeData as $college): ?>
          <div class="result">
            <h3><?php echo htmlspecialchars($college["name"]); ?></h3>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($college["location"]); ?></p>
            <p><strong>Stream:</strong> <?php echo htmlspecialchars($college["stream"]); ?></p>
            <p><strong>Fees:</strong> ₹<?php echo number_format($college["fees"]); ?></p>
            <p>
              <strong>Website:</strong>
              <a href="<?php echo htmlspecialchars($college["website"]); ?>" target="_blank" rel="noopener noreferrer">
                Visit Site <i class="fas fa-external-link-alt"></i>
              </a>
            </p>
            <form action="php/add_review.php" method="GET" style="margin-top: 10px;">
              <input type="hidden" name="college_id" value="<?php echo $college['id']; ?>">
              <button type="submit"><i class="fas fa-pen"></i> Review this college</button>
            </form>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="no-result">No college found with that name.</p>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<script>
  const input = document.getElementById("collegeInput");
  const resultsContainer = document.getElementById("resultsContainer");

  input.addEventListener("input", () => {
    resultsContainer.style.display = input.value.trim() === "" ? "none" : "block";
  });

  window.addEventListener("DOMContentLoaded", () => {
    resultsContainer.style.display = input.value.trim() === "" ? "none" : "block";
  });
</script>

</body>
</html>