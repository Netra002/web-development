// Clear form if page is restored from back/forward cache
window.addEventListener('pageshow', function (event) {
    const navType = performance.getEntriesByType("navigation")[0]?.type;

    if (event.persisted || navType === "back_forward") {
        const form = document.getElementById("reviewForm");
        if (form) {
            form.reset();
        }
    }
});

// Clear and fade out success message after submit
function clearFormAfterSubmit() {
    const form = document.getElementById("reviewForm");
    const msg = document.getElementById("successMessage");

    if (form) form.reset();

    if (msg) {
        msg.style.display = "block";
        msg.style.transition = "opacity 0.5s ease";
        setTimeout(() => {
            msg.style.opacity = 0;
            setTimeout(() => {
                msg.remove();
            }, 500);
        }, 3000);
    }
}

// Run clear function if success message is present
window.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById("successMessage")) {
        clearFormAfterSubmit();
    }
});
