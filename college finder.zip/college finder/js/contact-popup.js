function closePopup() {
    const popup = document.getElementById('successPopup');
    popup.style.display = 'none';
    // Remove ?status=success from URL
    window.history.replaceState({}, document.title, window.location.pathname);
  }
  
  // Show popup only once
  window.addEventListener('DOMContentLoaded', () => {
    if (typeof shouldShowPopup !== 'undefined' && shouldShowPopup) {
      const popup = document.getElementById('successPopup');
      popup.style.display = 'flex';
    }
  });
  