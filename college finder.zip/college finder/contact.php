<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.html");
    exit();
}
$showSuccessPopup = isset($_GET['status']) && $_GET['status'] === 'success';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <link rel="stylesheet" href="css/contact.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="top-bar">
  <div class="user-info">
    Logged in as: <strong><?php echo htmlspecialchars($_SESSION["username"]); ?></strong>
  </div>
  <a class="logout-link" href="php/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="contact-wrapper">
  <div class="contact-box">
    <h1><i class="fas fa-paper-plane"></i> Contact Us</h1>
    <p class="subtitle">If you have any questions, feedback, or need support, feel free to reach out!</p>

    <form method="POST" action="php/send_contact.php">
      <div class="input-group">
        <label for="subject"><i class="fas fa-tag"></i> Subject</label>
        <input type="text" name="subject" id="subject" required>
      </div>

      <div class="input-group">
        <label for="message"><i class="fas fa-comment-dots"></i> Message</label>
        <textarea name="message" id="message" rows="5" required></textarea>
      </div>

      <button type="submit"><i class="fas fa-paper-plane"></i> Send Message</button>
    </form>
  </div>
</div>

<!-- ✅ Popup Modal -->
<div class="popup" id="successPopup" style="display: none;">
  <div class="popup-content">
    <h2>✅ Message Sent!</h2>
    <p>Your message has been successfully sent.</p>
    <button onclick="closePopup()">OK</button>
  </div>
</div>

<!-- ✅ Include JavaScript -->
<script src="js/contact-popup.js"></script>
<script>
  // Pass PHP variable to JS
  const shouldShowPopup = <?php echo $showSuccessPopup ? 'true' : 'false'; ?>;
</script>

</body>
</html>
