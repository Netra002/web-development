<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $user_id = $_SESSION["user_id"];

    // You can save to DB or send email here...
    // For now, assume it's successful

    // Redirect back to contact page with success
    header("Location: ../contact.php?status=success");
    exit();
} else {
    header("Location: ../contact.php");
    exit();
}
