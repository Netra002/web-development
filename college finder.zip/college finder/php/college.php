<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $rating = $_POST['rating'];
    $description = $_POST['description'];

    $sql = "INSERT INTO college (name, location, type, rating, description)
            VALUES ('$name', '$location', '$type', '$rating', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "College added successfully!";
        echo "<br><a href='../college.html'>Add Another</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
