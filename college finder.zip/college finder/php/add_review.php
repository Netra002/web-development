<?php
session_start();
include_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to leave a review.";
    exit;
}

$college_id = $_GET['college_id'] ?? $_POST['college_id'] ?? null;
$college_name = '';
$success = false;

if ($college_id) {
    $stmt = $conn->prepare("SELECT name FROM colleges WHERE id = ?");
    $stmt->bind_param("i", $college_id);
    $stmt->execute();
    $stmt->bind_result($college_name);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $college_id = $_POST['college_id'];
    $user_id = $_SESSION['user_id'];
    $rating = $_POST['rating'];
    $comment = $conn->real_escape_string($_POST['comment']);

    $sql = "INSERT INTO reviews (user_id, college_id, rating, comment) 
            VALUES ('$user_id', '$college_id', '$rating', '$comment')";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../dashboard.php?review_success=1");

    exit;

    } else {
        $error = "❌ Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta charset="UTF-8">
    <title>Add Review</title>
    <link rel="stylesheet" href="../css/review.css">
</head>
<body>
    <div class="review-container">
        <h2>Add Review</h2>

        <?php if ($success): ?>
            <div id="successMessage" class="success-message">✅ Review added successfully!</div>
            <script>
                    setTimeout(() => {
                        const msg = document.getElementById('successMessage');
                if (msg) msg.style.display = 'none';
                      }, 3000); // Hides message after 3 seconds
            </script>
        <?php elseif (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($college_name): ?>
            <p><strong>College:</strong> <?php echo htmlspecialchars($college_name); ?></p>
        <?php else: ?>
            <p style="color: red;">College not found.</p>
        <?php endif; ?>

        <form id="reviewForm" action="add_review.php?college_id=<?php echo urlencode($college_id); ?>" method="POST">
            <input type="hidden" name="college_id" value="<?php echo htmlspecialchars($college_id); ?>">

            <div class="form-group">
                <label for="rating">Rating (1 to 5):</label>
                <select id="rating" name="rating" required>
                    <option value="1">⭐</option>
                    <option value="2">⭐⭐</option>
                    <option value="3">⭐⭐⭐</option>
                    <option value="4">⭐⭐⭐⭐</option>
                    <option value="5">⭐⭐⭐⭐⭐</option>
                </select>
            </div>

            <div class="form-group">
                <label for="comment">Your Comment:</label>
                <textarea id="comment" name="comment" rows="4" required></textarea>
            </div>

            <button type="submit">Submit Review</button>
        </form>
    </div>

    <script src="../js/clear form.js"></script>
</body>
</html>
