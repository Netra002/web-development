<?php
include_once 'db.php';

$location = $_GET['location'] ?? '';
$stream = $_GET['stream'] ?? '';
$max_fees = $_GET['max_fees'] ?? '';

$query = "SELECT name, location, stream, fees, website FROM colleges WHERE 1=1";

$params = [];
$types = "";

if (!empty($location)) {
    $query .= " AND location LIKE ?";
    $params[] = "%$location%";
    $types .= "s";
}

if (!empty($stream)) {
    $query .= " AND stream = ?";
    $params[] = $stream;
    $types .= "s";
}

if (!empty($max_fees)) {
    $query .= " AND fees <= ?";
    $params[] = $max_fees;
    $types .= "i";
}

$stmt = $conn->prepare($query);

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($college = $result->fetch_assoc()) {
        echo "<div class='college' style='margin-bottom: 20px; padding: 15px; border: 1px solid #ccc; border-radius: 8px;'>";
        echo "<h3>" . htmlspecialchars($college['name']) . "</h3>";
        echo "<p>📍 <strong>Location:</strong> " . htmlspecialchars($college['location']) . "</p>";
        echo "<p>📚 <strong>Stream:</strong> " . htmlspecialchars($college['stream']) . "</p>";
        echo "<p>💰 <strong>Fees:</strong> ₹" . htmlspecialchars($college['fees']) . "</p>";

        if (!empty($college['website'])) {
            echo "<p>🔗 <strong>Website:</strong> <a href='" . htmlspecialchars($college['website']) . "' target='_blank'>" . htmlspecialchars($college['website']) . "</a></p>";
        }

        echo "</div>";
    }
} else {
    echo "<p>No colleges found matching your criteria.</p>";
}

$conn->close();
?>
